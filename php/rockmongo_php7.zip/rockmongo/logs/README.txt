Query logs goes here, you should make this directory writeable.
